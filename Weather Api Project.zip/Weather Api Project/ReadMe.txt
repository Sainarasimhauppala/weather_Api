This is a JavaScript Based weather API Project :
    This web project is Responsive that menas this can be used in both 
    computer and mobile But if you want to use this in mobile you need to
    host this website 

You can use this by 
just save this Folder to your computer/Pc
and open the project folder 
click index.html
now it will open browser use crome which is preferd 
it will ask for location Allow the location
 >>>but make sure to connect to internet befor opening index.html because it uses internet for current location weather data >>>

.........Thats it...........